#!/usr/bin/env python3
"""Validate the AI Content Guidelines skill package.

Checks:
  - SKILL.md has frontmatter with a valid name, a description and a version
  - every JSON manifest parses
  - the version is the same in SKILL.md, package.json, the plugin manifests
    and the newest CHANGELOG.md entry
  - SKILL.md stays under the word limit
  - no unreplaced placeholders remain (warning only)

Uses the Python standard library only. Exit code 1 means a check failed.
"""

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MAX_WORDS = 5000
NAME_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")

errors: list[str] = []
warnings: list[str] = []


def read(rel: str) -> str:
    path = ROOT / rel
    if not path.exists():
        errors.append(f"Missing file: {rel}")
        return ""
    return path.read_text(encoding="utf-8")


def parse_frontmatter(text: str) -> tuple[dict, str]:
    """Minimal parser for the simple frontmatter this skill uses."""
    if not text.startswith("---"):
        errors.append("SKILL.md: frontmatter must start with '---'")
        return {}, text
    parts = text.split("---", 2)
    if len(parts) < 3:
        errors.append("SKILL.md: frontmatter is not closed with '---'")
        return {}, text
    data: dict = {}
    parent = None
    for line in parts[1].splitlines():
        if not line.strip():
            continue
        if line.startswith((" ", "\t")) and parent:
            key, _, value = line.strip().partition(":")
            data.setdefault(parent, {})[key.strip()] = value.strip().strip('"\'')
            continue
        key, _, value = line.partition(":")
        key, value = key.strip(), value.strip()
        if value:
            data[key] = value.strip('"\'')
            parent = None
        else:
            data[key] = {}
            parent = key
    return data, parts[2]


def load_json(rel: str) -> dict:
    text = read(rel)
    if not text:
        return {}
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        errors.append(f"{rel}: invalid JSON ({exc})")
        return {}


# SKILL.md
skill_text = read("SKILL.md")
fm, body = parse_frontmatter(skill_text) if skill_text else ({}, "")
name = fm.get("name", "")
if not NAME_RE.match(name):
    errors.append(f"SKILL.md: name '{name}' must be lowercase letters, digits and hyphens")
if len(name) > 64:
    errors.append("SKILL.md: name must be 64 characters or fewer")
description = fm.get("description", "")
if not description:
    errors.append("SKILL.md: description is missing")
elif len(description) > 1024:
    errors.append("SKILL.md: description must be 1024 characters or fewer")
skill_version = fm.get("metadata", {}).get("version", "") if isinstance(fm.get("metadata"), dict) else ""
if not skill_version:
    errors.append("SKILL.md: metadata.version is missing")

words = len(body.split())
if words > MAX_WORDS:
    errors.append(f"SKILL.md: {words} words, limit is {MAX_WORDS}")

# Manifests
versions = {"SKILL.md": skill_version}
pkg = load_json("package.json")
versions["package.json"] = pkg.get("version", "")
claude_plugin = load_json(".claude-plugin/plugin.json")
versions[".claude-plugin/plugin.json"] = claude_plugin.get("version", "")
marketplace = load_json(".claude-plugin/marketplace.json")
plugins = marketplace.get("plugins") or [{}]
versions[".claude-plugin/marketplace.json"] = plugins[0].get("version", "")
cursor_plugin = load_json(".cursor-plugin/plugin.json")
versions[".cursor-plugin/plugin.json"] = cursor_plugin.get("version", "")

for rel, manifest in [(".claude-plugin/plugin.json", claude_plugin), (".cursor-plugin/plugin.json", cursor_plugin)]:
    if manifest and manifest.get("name") != name:
        errors.append(f"{rel}: name '{manifest.get('name')}' does not match SKILL.md name '{name}'")
if plugins[0] and plugins[0].get("name") != name:
    errors.append(".claude-plugin/marketplace.json: plugin name does not match SKILL.md name")

# Changelog
changelog = read("CHANGELOG.md")
match = re.search(r"^##\s+\[?(\d+\.\d+\.\d+)", changelog, re.MULTILINE)
versions["CHANGELOG.md (newest entry)"] = match.group(1) if match else ""

distinct = {v for v in versions.values()}
if len(distinct) != 1 or "" in distinct:
    errors.append("Versions do not match:\n" + "\n".join(f"    {k}: {v or '(missing)'}" for k, v in versions.items()))

# Required files
for rel in ["README.md", "LICENSE", "agents/openai.yaml"]:
    read(rel)

# Placeholders (warning only, so forks still validate before setup)
for rel in ["README.md", "LICENSE", "package.json", ".claude-plugin/plugin.json",
            ".claude-plugin/marketplace.json", ".cursor-plugin/plugin.json"]:
    path = ROOT / rel
    if path.exists() and re.search(r"YOUR_GITHUB_USERNAME|\[YOUR NAME\]", path.read_text(encoding="utf-8")):
        warnings.append(f"{rel}: placeholder text still present")

# Report
for w in warnings:
    print(f"WARNING: {w}")
if errors:
    for e in errors:
        print(f"ERROR: {e}")
    sys.exit(1)
print(f"OK: {name} v{skill_version}, {words} words in SKILL.md, all versions in sync.")
